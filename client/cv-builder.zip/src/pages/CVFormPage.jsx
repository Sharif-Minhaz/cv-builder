import CVForm from "../components/Form";

export default function CVFormPage() {
	return (
		<div>
			<CVForm />
		</div>
	);
}
