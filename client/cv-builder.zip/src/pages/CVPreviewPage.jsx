import CVContent from "../components/CVContent";

export default function CVPreviewPage() {
	return (
		<div>
			<CVContent />
		</div>
	);
}
